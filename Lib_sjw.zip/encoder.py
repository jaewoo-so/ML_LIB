'''

카테고리컬 데이터를 넣으면, 구현된 방법들로 추가 피쳐를 만들어 내도록 

'''

import pandas as pd
from sklearn.preprocessing import LabelEncoder, LabelBinarizer, OneHotEncoder

def label_encoding_all_col(df):
    pass



if __name__ == '__main__':
    pass
