model_interface.py
- [x] xg , lgbm , cat boost
- [x] tree based : rf , extra tree , 
- [x] svm
- [x] linear
- [x] lda , qda
-
-
